//
//  TypeArray.swift
//  Example
//
//  Created by 程庆春 on 2016/10/18.
//  Copyright © 2016年 qiuncheng.com. All rights reserved.
//

import FontAwesomeKit_Swift

struct Types {
    static let types: [FontAwesomeType] = {
        return FontAwesomeType.allCases
    }()
}

